Climate risk and agricultural commodities — Beamer slides

Compile with:
  pdflatex slides_climate_risk.tex
  pdflatex slides_climate_risk.tex

Files in figures/ come from notebook project_notebook_V20(3).ipynb:
- climate_index.png: cell 11
- news_attention_global_warming.png: cropped global-warming panel from cell 19
- strategy_wealth_exposure.png: cell 54
- strategy_benchmarks.png: cell 72
- placebo.png: cell 62 (appendix)

Tables come from notebook cells 39, 48 and user-reported 6m ML output (cell 69).
The final slide explicitly flags the six-month target overlap in the validation split.
Please review the numbers if you re-run or change the original notebook.
